// IKONOK.HU: az oldal halozat-elso (offline a mentett valtozat), az ikonok es kepek gyorsitotar-elsok
const V = 'ikonok-it202610241541';
const PRE = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './favicon-32.png'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(V).then(c => c.addAll(PRE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  // a gyökér service workere nem kezeli a többi ország mappáját (/jp/ stb.), azoknak saját sw.js-ük van
  if (location.pathname === '/sw.js' && /^\/[a-z]{2}(\/|$)/.test(u.pathname)) return;
  if (/\/ikon\/|\/a\/|\.(png|jpg|ico|svg)$/.test(u.pathname)) {
    e.respondWith(caches.match(e.request).then(r => r || fetch(e.request).then(res => {
      if (res.ok) { const cp = res.clone(); caches.open(V).then(c => c.put(e.request, cp)); }
      return res;
    })));
  } else if (e.request.mode === 'navigate') {
    e.respondWith(fetch(e.request).then(res => {
      const cp = res.clone(); caches.open(V).then(c => c.put('./index.html', cp)); return res;
    }).catch(() => caches.match('./index.html')));
  }
});
